# pySOM
Self-organizing Maps,SOM for python
